public class test1 {
    public static void main(String[] args) {
        int[] nums= {34,4,31,23,54,65};
        int min=0;//用于记录每次比较的最小值下标
        for(int i=0;i<nums.length-1;i++)
        {
            min=i;
            for(int j=i+1;j<nums.length;j++) {
                if(nums[min]>nums[j]) {
                    min=j;
                }
            }
            //判断需要交换的数下标是否是自己
            if(min!=i)
            {
                nums[min]=nums[min]+nums[i];
                nums[i]=nums[min]-nums[i];
                nums[min]=nums[min]-nums[i];
            }
        }
        for(int n:nums)
        {
            System.out.println(n);
        }
    }
}
